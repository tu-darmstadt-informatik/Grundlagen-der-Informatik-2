import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class ListFileReader{

	private String filename = null;
	private List<String> dataList = null;

	public ListFileReader(String filename) {
		this.filename = filename;
		this.dataList = new LinkedList<String>();
		readFile();
	}

	public void readFile() {
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader in = new BufferedReader(fr);
			String line;
			while((line = in.readLine())!=null) {
				dataList.add(line);
				for (int i=0; i<100; i++)
					dataList.add(line + i);
			}

			in.close();
			fr.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	

	public List<String> getList(){
		return dataList;
	}
}
