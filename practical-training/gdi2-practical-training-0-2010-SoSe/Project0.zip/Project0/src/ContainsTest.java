import static org.junit.Assert.*;
import java.util.LinkedList;

import org.junit.BeforeClass;
import org.junit.Test;

public class ContainsTest {

	static ListFileReader fr = null;
	static Contains c = null;
	static String myCountry = null;
	static String noCountry = null;
	
	
	@BeforeClass
	public static void init() {
		c = new Contains();
		fr = new ListFileReader("countries.txt");
		myCountry = "Senegal";
		noCountry = "12345";
	}
	
	@Test
	public void testJavaContainsTrue() {
		assertTrue(c.contains_java(fr.getList(), myCountry));
	}

	@Test
	public void testJavaContainsFalse() {
		assertFalse(c.contains_java(fr.getList(), noCountry));
	}

	@Test
	public void testJavaContainsEmptyList() {
		assertFalse(c.contains_java(new LinkedList<String>(), noCountry));
	}

	@Test
	public void testLectureContainsTrue() {
		assertTrue(c.contains_lecture(fr.getList(), myCountry));
	}

	@Test
	public void testLectureContainsFalse() {
		assertFalse(c.contains_lecture(fr.getList(), noCountry));
	}

	@Test
	public void testLectureContainsEmptyList() {
		assertFalse(c.contains_lecture(new LinkedList<String>(), noCountry));
	}

	@Test
	public void testFastContainsTrue() {
		assertTrue(c.contains_fast(fr.getList(), myCountry));
	}

	@Test
	public void testFastContainsFalse() {
		assertFalse(c.contains_fast(fr.getList(), noCountry));
	}

	@Test
	public void testFastContainsEmptyList() {
		assertFalse(c.contains_fast(new LinkedList<String>(), noCountry));
	}


}