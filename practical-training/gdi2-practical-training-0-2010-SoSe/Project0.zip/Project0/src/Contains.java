/*******************************************************************
 * Questions / Fragen
 *******************************************************************
 * a) How does the measured performance of contains_fast and 
 * contains_lecture relate to each other? Explain the result!
 *
 * Wie verh�lt sich die gemessene Laufzeit von den Methoden 
 * contains_fast und contains_lecture zu einander?  
 * Erkl�ren Sie das Ergebnis!
 * ----------------------------------------------------------------
 * 
 * TODO: Answer / Antwort
 * 
 * ----------------------------------------------------------------
 * b) The method contains_java calls the predefined Java contains 
 * function for Lists. How does contains_java perform compared to 
 * the other methods? Do you have an idea, why?
 * 
 * Die Methode contains_java ruft die in der Java-API vordefinierte 
 * contains-Funktion f�r Listen auf. Wie verh�lt sich die Laufzeit 
 * von contains_java zu den anderen? Was k�nnte der Grund sein?
 * ----------------------------------------------------------------
 * 
 * TODO: Answer / Antwort
 * 
 *******************************************************************/
import java.util.List;
import java.util.Random;


/**
 * This class offers three different implementations of the "contains" method.
 * Each method takes a list of strings and a string and checks whether the
 * string is contained in the list. 
 */
public class Contains {

	/**
	 * Calls the "contains"-function predefined by the Java List class. 
	 * 
	 * @param list A list of strings
	 * @param element A single string
	 * @return True if element is contained in list, false otherwise.
	 */
	public boolean contains_java(List<String> list, String element) {
		return list.contains(element);
	}


	/**
	 * The contains function as defined in the lecture 
	 * (Slide set 3, page 11).
	 * 
	 * @param list A list of strings
	 * @param element A single string
	 * @return True if element is contained in list, false otherwise.
	 */
	public boolean contains_lecture(List<String> list, String element) {
		boolean found = false;
		for (String s : list) {
			if (s.equals(element))
				found = true;
		}
		return found;	
	}

	/**
	 * TODO: Implement a small optimization for the contains function
	 * defined in the lecture: As soon as the element is found,
	 * you do not need to continue the iteration.
	 * 
	 * @param list A list of strings
	 * @param element A single string
	 * @return True if element is contained in list, false otherwise.
	 */
	public boolean contains_fast(List<String> list, String element) {
		// TODO: Replace the next line with your implementation
		throw new UnsupportedOperationException("Implement me!");
	}

	/**
	 * Reads a list and performs a lot of random lookups using the three
	 * contains methods defined above. The elements looked for are
	 * randomly chosen from the list beforehand.
	 * 
	 * @param argv not used
	 */
	public static void main(String[] argv) {
		Contains c = new Contains();
		// Reads a long list of strings
		ListFileReader fr = new ListFileReader("countries.txt");
		// Random number generator
		Random rand = new Random();
		List<String> list = fr.getList();
		int length = list.size();

		for (int i=0; i<5000; i++) {
			// Read a random string from the list
			String string = list.get(rand.nextInt(length));
			// Check whether the string is contained (should always return true)
			c.contains_lecture(list, string);
			c.contains_fast(list, string);
			c.contains_java(list, string);
		}
	}
}
