
public class ObjectAlreadyPresentException extends RuntimeException {

	private static final long serialVersionUID = -6499002999657327239L;

}
