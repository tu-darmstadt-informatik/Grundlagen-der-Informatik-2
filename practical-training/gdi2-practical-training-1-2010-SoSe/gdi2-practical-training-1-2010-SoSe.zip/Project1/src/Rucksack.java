/**
 * The Rucksack class represents a rucksack that holds objects
 * of type PackingObject. Implement the predefined interface and
 * use it from RucksackProblem.java to solve a Rucksack problem
 * instance.
 */
public class Rucksack {

	// TODO: Specify private data, variables
	
	/**
	 * Initializes a new Rucksack object with a given capacity. 
	 * Sets up all required data structures.
	 * 
	 * @param capacity The capacity of the Rucksack.
	 */
	public Rucksack(int capacity) {
		// TODO: Implement constructor
	}
	
	/**
	 * Inserts an object into the Rucksack.
	 * 
	 * @param o The object to be added. 
	 * @throws ObjectAlreadyPresentException if the object is already present.
	 * @throws CapacityExceededException if the capacity is exceeded by the 
	 *         new object.
	 */
	void putObject(PackingObject o) {
		// TODO: Implement function
	}
	
	/**
	 * Removes an object from the Rucksack.
	 * 
	 * @param o The object to be removed.
	 * @throws ObjectNotPresentException if the object is not in the rucksack.
	 */
	void removeObject(PackingObject o) {
		// TODO: Implement function
	}
	
	/**
	 * Checks whether an object is contained in the Rucksack
	 * 
	 * @param o The object to check for.
	 * @return True if the object is present, false otherwise.
	 */
	public boolean contains(PackingObject o) {
		// TODO: Implement function
		return false;
	}

	/**
	 * Returns the total weight of all objects in the rucksack.
	 */
	public int getTotalWeight() {
		// TODO: Implement.
		return -1;
	}

	/**
	 * Returns the total value of all objects in the rucksack.
	 */
	public int getTotalValue() {
		// TODO: Implement.
		return -1;
	}

	/**
	 * Returns the initial capacity of the rucksack.
	 */
	public int getTotalCapacity() {
		// TODO: Implement.
		return -1;
	}
	
	/**
	 * Returns the capacity of the Rucksack still available.
	 */
	public int getAvailableCapacity() {
		// TODO: Implement
		return -1;
	}

	/**
	 * Copies the contents of another Rucksack to this Rucksack.
	 *  
	 * @param other The Rucksack to copy from.
	 */
	public void copyFrom(Rucksack other) {
		// TODO: Implement
	}

	/**
	 * Prints all objects in this Rucksack by iterating over a list of
	 * passed PackingObjects and checking for each object whether it
	 * is in the Rucksack using contains().
	 * 
	 * You can use this function for debugging purposes.
	 *  
	 * @param objects The complete list of objects that might be in the 
	 *                rucksack
	 * @return A string of the format [(value1,weight1), (value2,weight2), ...]
	 */
	public String toString(PackingObject[] objects) {
		StringBuilder sb = new StringBuilder();
		sb.append('[');
		for (PackingObject object : objects) {
			if (contains(object))
				sb.append(object.toString()).append(", ");
		}
		if (sb.length() > 1)
			sb.delete(sb.length() - 2, sb.length());
		sb.append(']');
		return sb.toString();
	}
}