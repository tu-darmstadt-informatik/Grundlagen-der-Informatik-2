/**
 * An object that can be put into a Rucksack. Each PackingObject
 * has a value and a weight.
 * 
 * Each PackingObject also has a unique index, which you can use
 * for an optimized storing of PackingObjects in a Rucksack.
 * 
 * @author Johannes Kinder
 */
public class PackingObject {
	
	private static int maxIndex = 0;
	
	/**
	 * Returns the number of PackingObjects that have been created.
	 * All test cases ensure that all PackingObjects have been created 
	 * before the first Rucksack object is created. Therefore, you can safely
	 * use this function to get the total number of PackingObjects.
	 * 
	 * @return the number of packing objects that have been created.
	 */
	public static int getTotalNumberOfObjects() {
		return maxIndex;
	}
	
	/**
	 * This is used by the test cases to reset the counter for PackingObjects.
	 */
	public static void reset() {
		maxIndex = 0;
	}
	
	private final int value;
	private final int weight;
	private final int index;
	
	public PackingObject(int value, int weight) {
		this.value = value;
		this.weight = weight;
		this.index = maxIndex++;
	}

	/**
	 * Returns the unique index of this PackingObject.
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * Returns the value of this PackingObject.
	 */
	public int getValue() {
		return value;
	}

	/**
	 * Returns the weight of this PackingObject.
	 */
	public int getWeight() {
		return weight;
	}

	/**
	 * Creates a string representation of this PackingObject of the
	 * form (value,weight).
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append('(').append(getValue()).append(',').append(getWeight()).append(')');
		return sb.toString();
	}
}
