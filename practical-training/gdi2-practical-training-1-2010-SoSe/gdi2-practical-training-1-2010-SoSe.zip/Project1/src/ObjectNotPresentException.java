
public class ObjectNotPresentException extends RuntimeException {

	private static final long serialVersionUID = 1870950568231197185L;

}
