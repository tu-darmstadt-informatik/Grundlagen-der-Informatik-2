
public class CapacityExceededException extends RuntimeException {

	private static final long serialVersionUID = -3768115092191702079L;

}
