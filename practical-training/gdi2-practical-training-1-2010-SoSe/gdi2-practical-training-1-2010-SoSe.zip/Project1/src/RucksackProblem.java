/*******************************************************************
 * Questions / Fragen
 *******************************************************************
 * a) What are the asymptotic time complexities T(n) of the 
 * recursive and iterative versions of the algorithm, with n being 
 * the total number of available packing objects? State your answer 
 * in big-Oh notation.
 *
 * Was sind die Laufzeitkomplexit�ten T(n) der rekursiven und der
 * iterativen Version des Algorithmus, wobei n die Anzahl der 
 * packbaren Objekte ist? Geben Sie die Komplexit�t in O-Notation an.
 * ----------------------------------------------------------------
 * 
 * TODO: Answer / Antwort
 * 
 * ----------------------------------------------------------------
 * b) Use TPTP to profile RucksackProblem.main(). Try different 
 * values for the variable numObjects in main() and measure the 
 * total execution time of solveRecursive(int) and solveIterative,
 * and the number of recursive calls to solveRecursive. To what 
 * problem size can you go on your machine? 
 * Enter at least 5 different, meaningful runs in the table below. 
 * 
 * Verwenden Sie TPTP um RucksackProblem.main() zu profilen. 
 * Probieren Sie verschiedene Werte f�r die Variable numObjects in
 * main() aus und messen Sie die Laufzeit von solveRecursive(int)
 * und solveIterative sowie die Anzahl der rekursiven Aufrufe von 
 * solveRecursive(int). Bis zu welcher Gr��e k�nnen Sie auf Ihrem 
 * Rechner gehen? Tragen Sie mindestens
 * 5 verschiedene, aussagekr�ftige Resultate in der Tabelle ein. 
 * ----------------------------------------------------------------
 * 
 * TODO: Answer / Antwort
 * 
 * numObj	| Cumul. time (iter)| Cumul. time (rec) | Recursive calls
 * ---------+-------------------+-------------------+----------------
 * 			|					|					|	
 * 			|					|					|	
 * 			|					|					|	
 * 			|					|					|	
 * 			|					|					|	
 * 			|					|					|	
 * 
 *******************************************************************/
import java.util.Deque;
import java.util.LinkedList;
import java.util.Random;

/**
 * A class describing an instance of the Rucksack problem. A call to the
 * constructor initializes the problem, and a call to solve() starts a
 * recursive search.
 */
public class RucksackProblem {
	
	private PackingObject[] objects;
	// TODO: Specify private data structures
	
	/**
	 * The constructor initializes the class with a set of objects to pack
	 * and a rucksack of a given capacity. 
	 *  
	 * @param objects An array of PackingObjects to store optimally in the 
	 *                rucksack
	 * @param rucksack A Rucksack that has been initialized with some 
	 *                capacity
	 */
	public RucksackProblem(PackingObject[] objects, Rucksack rucksack) {

		// TODO: Check arguments, throw IllegalArgumentException if necessary

		this.objects = objects;

		// TODO: Initialize private data structures
	}
	
	public Rucksack getOptimalRucksack() {
		// TODO: Return the best rucksack, the result of the algorithm 
		return null;
	}
	
	public PackingObject[] getAllObjects() {
		return objects;
	}

	/**
	 * Start the recursive algorithm to solve the Rucksack problem at
	 * the 0-th object.
	 */
	public void solveRecursive() {
		solveRecursive(0);
	}
	
	/**
	 * The recursive algorithm. Do not use loops here, implement only
	 * using recursive calls. 
	 * 
	 * For every object, tries to solve the rest of the problem both 
	 * with the object and without the object using recursive calls 
	 * to solveRecursive(i+1).
	 * 
	 * @param i the current position in the object array. 
	 */
	private void solveRecursive(int i) {
		// TODO: Implement a recursive depth first search.
	}
	
	/**
	 * The iterative version of the algorithm. Do not include any
	 * recursive calls, but implement it using a loop and a stack.
	 */
	public void solveIterative() {

		// A stack to use with the algorithm
		Deque<Integer> stack = new LinkedList<Integer>();

		// The current position in the array of objects
		int i = 0;
		
		// TODO: Implement the algorithm sketched below:

		// Loop:
		//	 	Have we processed all objects?
		// 			Stop if there are no backtracking points left
		// 			Else backtrack to last object that was put into rucksack 
		// 			Remove it and continue with next object
		//
		// 		Does the object still fit into the available capacity?
		// 			Put object into rucksack
		// 			Remember this object as a backtracking point
		// 			Remember if the new rucksack is the best we know
		//
		// 		Continue loop with next object
	}

	public static void main(String[] argv) {
		// TODO: Try different values for numObjects
		int numObjects = 5;
		
		PackingObject[] objects = new PackingObject[numObjects];
		Random rand = new Random();
		for (int i=0; i<numObjects; i++) {
			objects[i] = new PackingObject(rand.nextInt(100), rand.nextInt(100));
		}

		// Invoke recursive algorithm
		Rucksack rucksack = new Rucksack(numObjects * 25);
		RucksackProblem problem = new RucksackProblem(objects, rucksack);
		problem.solveRecursive();

		// Invoke iterative algorithm
		rucksack = new Rucksack(numObjects * 25);
		problem = new RucksackProblem(objects, rucksack);
		problem.solveIterative();
	}
}
