import java.util.*;

/**
 * A binary tree in sequential representation. It is maintained as an array such that
 * the left child of the node with index i is located at index 2i and the right child 
 * is located at index 2i + 1 (see lecture slide set 7). The root is at index 1. 
 *
 * @param <A> The type of the data held in nodes of the tree.
 */
public class SequentialBinaryTree<A> implements BinaryTree<A> {

	/**
	 * Create a tree from a given animal game preorder.
	 * 
	 * @param <B> The type of the data held in nodes of the tree.
	 * @param preorder The preorder to build the tree from.
	 * @return A new SequentialBinaryTree corresponding to the provided preorder.
	 */
	public static SequentialBinaryTree<String> createFromPreorder(List<String> preorder) {
		// TODO: Implement
		throw new UnsupportedOperationException();
	}

	/**
	 * Create a pre-order traversal sequence for this tree.
	 * 
	 * @return The pre-order sequence for this tree.
	 */
	@Override
	public List<A> preorder() {
		// TODO: Implement
		throw new UnsupportedOperationException();
	}

	@Override
	public BinaryTreeSearch<A> binaryTreeSearch() {
		// Create anonymous class implementing BinaryTreeSearch
		return new BinaryTreeSearch<A>() {

			@Override
			public A getData() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public boolean isLeaf() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public void nextLeftChild() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public void nextRightChild() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public void setNode(A data, A leftData, A rightData) {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public boolean hasLeftChild() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public boolean hasRightChild() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}
		};
	}

}
