import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Interactive I/O for the quiz.
 */
public class UserIoAdapter implements QuizIoAdapter {

	private BufferedReader inputReader;

	public UserIoAdapter() {
		inputReader = new BufferedReader(new InputStreamReader(System.in));
	}

	@Override
	public String askString(String question) {
		tell(question);
		try {
			return inputReader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean askYesNo(String question) {
		String answer = askString(question + " (Y/N)").toUpperCase();

		while (!answer.startsWith("Y") && !answer.startsWith("N"))
		{
			answer = askString("Please answer Y or N: ").toUpperCase( );
		}

		return answer.startsWith("Y");		
	}

	@Override
	public void tell(String message) {
		System.out.println(message);
	}

}
