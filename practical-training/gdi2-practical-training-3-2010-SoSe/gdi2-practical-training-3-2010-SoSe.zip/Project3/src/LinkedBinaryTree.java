import java.util.*;

/**
 * A binary tree in linked representation. Tree nodes are stored as objects consisting of
 * pointers to their left and right child and to their associated data.
 *
 * @param <A> The type of the data held in nodes of the tree.
 */
public class LinkedBinaryTree<A> implements BinaryTree<A> {

	/**
	 * Create a tree from a given animal game preorder. 
	 * 
	 * @param <B> The type of the data held in nodes of the tree.
	 * @param preorder The preorder to build the tree from.
	 * @return A new LinkedBinaryTree corresponding to the provided preorder.
	 */
	public static LinkedBinaryTree<String> createFromPreorder(List<String> preorder) {
		// TODO: Implement
		throw new UnsupportedOperationException();
	}

	/**
	 * Create a pre-order traversal sequence for this tree.
	 * 
	 * @return The pre-order sequence for this tree.
	 */
	@Override
	public List<A> preorder() {
		// TODO: Implement
		throw new UnsupportedOperationException();
	}

	@Override
	public BinaryTreeSearch<A> binaryTreeSearch() {
		// Create anonymous class implementing BinaryTreeSearch
		return new BinaryTreeSearch<A>() {
			
			@Override
			public A getData() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public boolean isLeaf() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public void nextLeftChild() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public void nextRightChild() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public void setNode(A data, A leftData, A rightData) {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public boolean hasLeftChild() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}

			@Override
			public boolean hasRightChild() {
				// TODO: Implement
				throw new UnsupportedOperationException();
			}			
		};
	}

}
