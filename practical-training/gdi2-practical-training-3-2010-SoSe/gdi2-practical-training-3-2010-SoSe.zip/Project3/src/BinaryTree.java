import java.util.List;

/**
 * A simple generic interface for binary trees to be used by the Quiz class.
 * 
 * @param <A> The type of the data held in nodes of the tree.
 */
public interface BinaryTree<A> {
	
	/**
	 * Initiates a new search from the root of this binary tree. This method
	 * can be implemented by creating an anonymous class of type BinaryTreeSearch,
	 * similar to many Iterator implementations.
	 * 
	 * @return A new object of type BinaryTreeSearch. 
	 */
	public BinaryTreeSearch<A> binaryTreeSearch();
	
	/**
	 * Produces a pre-order traversal sequence for this tree.
	 * 
	 * @return A list of data objects in pre-order.
	 */
	public List<A> preorder();
	
}
