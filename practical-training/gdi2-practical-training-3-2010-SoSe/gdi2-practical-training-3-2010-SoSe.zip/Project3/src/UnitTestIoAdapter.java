import static org.junit.Assert.*;
import java.util.Deque;
import java.util.LinkedList;

/**
 * Pseudo I/O for the unit-testing the quiz.
 */
public class UnitTestIoAdapter implements QuizIoAdapter {

	private Deque<String> answerStrings;
	private Deque<Boolean> answerBools;
	private Deque<String> questions;
	
	public UnitTestIoAdapter() {
		answerStrings = new LinkedList<String>();
		answerBools = new LinkedList<Boolean>();
		questions = new LinkedList<String>();
	}
	
	public void queueAnswer(String answer) {
		answerStrings.add(answer);
	}
	
	public void queueAnswer(boolean answer) {
		answerBools.add(answer);
	}
	
	public void queueYesNoQuestion(String question) {
		questions.add(question);
	}
	
	@Override
	public String askString(String question) {
		System.out.println(question);
		System.out.println(answerStrings.getFirst());
		return answerStrings.removeFirst();
	}

	@Override
	public boolean askYesNo(String question) {
		System.out.println(question);
		assertTrue(question + " should contain " + questions.getFirst(), 
				question.contains(questions.removeFirst()));
		System.out.println(answerBools.getFirst() ? "Y" : "N");
		return answerBools.removeFirst();
	}

	@Override
	public void tell(String message) {
		System.out.println(message);
	}

}
