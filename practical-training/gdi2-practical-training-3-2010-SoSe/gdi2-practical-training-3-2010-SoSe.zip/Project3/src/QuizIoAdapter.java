/**
 * Interface for providing IO to the quiz game.
 */
public interface QuizIoAdapter {

	/**
	 * Ask the user or test system a yes/no question.
	 * 
	 * @param question The question to ask.
	 * @return True if the answer was "Y", false if it was "N".
	 */
	public boolean askYesNo(String question);
	
	/**
	 * Ask the user a general question.
	 * 
	 * @param question The question to ask.
	 * @return The answer given to the question.
	 */
	public String askString(String question);
	
	/**
	 * Output a message.
	 * 
	 * @param message The message to output.
	 */
	public void tell(String message);
}
