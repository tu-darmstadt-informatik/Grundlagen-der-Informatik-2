import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Methods needed to read and write the puzzle
 */

public class PuzzleInputOutput 
{
	private static String[][] puzzleStart;
	private static String[][] puzzleDestination;
	
	/**
	 * This method reads the data from the file and 
	 * initialises the Start and Destination states of the Puzzle
	 * 
	 * @param puzzleFile
	 * @throws IOException
	 */
	public PuzzleInputOutput(String puzzleFile) throws IOException
	{
		
		/* TODO: The following code can be used to start with the implementation
		 * // read the puzzle from file
		 * BufferedReader reader = new BufferedReader(new FileReader(puzzleFile));
		 * String line = reader.readLine();
		 * line = line.trim();
		 * // get the size of the puzzle (NxN)
		 * int size = Integer.parseInt(line);
		 * // initialise puzzle size 
		 * puzzleStart       = new String[size][size];
		 * puzzleDestination = new String[size][size];
		 * // read Start puzzle
		 * ...
		 */
		
		// TODO: Implement this method
		// TODO: Use where appropriate ... throw new PuzzleFileFormatException("Message...") ...
		// e.g.,
		// check if required puzzle fields are given
		// if ((line = reader.readLine()) == null)
		//  	throw new PuzzleFileFormatException("File has not enough lines.");
	}
	/**
	 * It prints the given puzzle state
	 * 
	 * @param puzzle the puzzle
	 */
	public static void printPuzzle(String[][] puzzle)
	{
		// TODO: Implement this method
	}
	/**
	 * @return the puzzleStart
	 */
	public String[][] getPuzzleStart() {
		return puzzleStart;
	}
	/**
	 * @return the puzzleDestination
	 */
	public String[][] getPuzzleDestination() {
		return puzzleDestination;
	}
}
