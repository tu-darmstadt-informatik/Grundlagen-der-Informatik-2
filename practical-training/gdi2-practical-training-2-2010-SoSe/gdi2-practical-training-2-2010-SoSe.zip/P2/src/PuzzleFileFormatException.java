/**
 * PuzzleFileFormatException
 */

public class PuzzleFileFormatException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
	/**
	 * PuzzleFileFormatException 
	 * @param s the message
	 */
	public PuzzleFileFormatException(String s) {
		super(s);
	}
}
