import java.util.List;

import org.jgrapht.DirectedGraph;

/**
 * This class represents the implementation of the A* algorithm 
 */

public abstract class PuzzleAStar {

	private DirectedGraph<PuzzleMove, Integer> graph; 	// vertex: PuzzleMove 
														//   edge: Integer (use an int value as a unique ID)
	private PuzzleMove startState;						// the start state of the puzzle
	private PuzzleMove destinationState;				// the destination state of the puzzle
	private PuzzleMove currentState;					// the current explored puzzle state	
	private List<PuzzleMove> movesToProcess;			// the number of moves not taken yet
	
	private long startPuzzleTime;   					// Timing variables
	private long endPuzzleTime;
	
	// TODO: Specify other private data, variables
	// TODO: Initialise the graph
	
	/**
	 * Initialises the graph
	 */
	void init() {
		// TODO: Implement method
	}
	/**
	 * This method implements the A* algorithm for the puzzle
	 */
	public void findDestination() {
		// TODO: Implement method
	}

	/**
	 * This method prints a summary of the solution
	 * 
	 * @param state The final puzzle state (Destination)
	 */
	public void printSolutionSummary(PuzzleMove state) {
		// TODO: Add code if needed
		// TODO: Remove comments and add needed code 
		// System.out.println("Time needed to find Destination (ms): " + // TODO);
	    // System.out.println("Current cost at final state (Destination): " + state.getCost());
	    // System.out.println("States processed so far: " + // TODO);
	    // System.out.println("States identified for processing (not being processed): " + // TODO);
	  }    
	/**
	 * This method prints the path to the solution
	 * 
	 * @param graph
	 */
	public void printPathToSolution(DirectedGraph<PuzzleMove, Integer> graph) {
		System.out.println("\nThe steps/path needed to reach the destination:\n");
		// TODO: Implement method
		// TODO: Include in each step the cost, ds and dd of the current state (PuzzleMove)
		// e.g.:
		//  	Step 9: cost = 3, ds = 9, dd = 7
		//		--------------------------------
		//		1 2 3
		//		4 5 7
		// 		6 8 #
		//
	  }
	/**
	 * The number of states identified for processing but not processed yet
	 * @return the number of moves not taken yet
	 */
	int numberOfStatesToProcess() {
		// TODO: Implement this method
		return -1;
	}	
	
	// TODO: Implement other necessary methods
	
	/**
	 * The number of states/puzzle moves processed so far
	 * @return the number of edges
	 */
	int numberOfProcessedStates() {
		return this.graph.vertexSet().size();
	}
	/**
	 * @return the graph
	 */
	public DirectedGraph<PuzzleMove, Integer> getGraph() {
		return this.graph;
	}

	/**
	 * @return the currentState
	 */
	public PuzzleMove getCurrentState() {
		return this.currentState;
	}

	/**
	 * @param destinationState the destinationState to set
	 */
	public void setDestinationState(PuzzleMove destinationState) {
		this.destinationState = destinationState;
	}

	/**
	 * @param startState the startState to set
	 */
	public void setStartState(PuzzleMove startState) {
		this.startState = startState;
	}

	/**
	 * @return the startState
	 */
	public PuzzleMove getStartState() {
		return this.startState;
	}

	/**
	 * @return the destinationState
	 */
	public PuzzleMove getDestinationState() {
		return this.destinationState;
	}
	/**
	 * @return the movesToProcess
	 */
	public List<PuzzleMove> getMovesToProcess() {
		return this.movesToProcess;
	}
}
