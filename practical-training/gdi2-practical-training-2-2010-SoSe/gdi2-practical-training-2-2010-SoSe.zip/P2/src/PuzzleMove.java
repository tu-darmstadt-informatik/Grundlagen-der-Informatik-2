import java.util.List;

/**
 * This class defines a puzzle move
 */

public class PuzzleMove 
{
	private int ds;					// distance from start
	private int dd;					// distance to destination
	private int cost; 				// the distance cost (cost = ds + dd)
	private int heuristic;	  		// used to set the heuristic to be applied
									// 0 - methodOne()
									// 1 - methodTwo()
									// 2 - methodThree()
	private String[][] state;		// the state of the current puzzle move/state
	// TODO: Specify other private data, variables	
	// TODO: Implement the getter/setter methods as needed
	// TODO: Implement other necessary methods, e.g., toString() if needed
	
	/**
	 * Calculates the possible successor moves/states
	 * @return a list with the successor moves/states
	 */
	public List<PuzzleMove> successorMoves() {
		// TODO: Implement this method
		return null;
	}
	/**
	 * Calculates the distance to the destination p (according to the currently chosen heuristic)
	 * @param p the destination state
	 * @return the distance of the current state to destination
	 */
	public int calculateDistance(PuzzleMove p) {
		// TODO: Implement this method
		return -1;
	}
	/**
	 * Heuristic 0
	 * 
	 * @param p the puzzle state
	 * @return  the destination cost according to this heuristic
	 */
	private int methodOne(PuzzleMove p) {
		// TODO: Implement the method
		return -1;
	}
	/**
	 * Heuristic 1
	 * 
	 * @param p the puzzle state
	 * @return  the destination cost according to this heuristic
	 */
	private int methodTwo(PuzzleMove p) {
		// TODO: Implement the method
		return -1;
	}
	/**
	 * Heuristic 2
	 * 
	 * @param p the puzzle state
	 * @return  the destination cost according to this heuristic
	 */
	private int methodThree(PuzzleMove p) {
		// TODO: Implement the method
		return -1;
	}
	/**
	 * Checks if two puzzle moves are equal
	 */
	boolean equals(PuzzleMove p) {
		// TODO: Implement the method
		return true;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String[][] state) {
		this.state = state;
	}
	/**
	 * @return the state
	 */
	public String[][] getState() {
		return state;
	}
}
