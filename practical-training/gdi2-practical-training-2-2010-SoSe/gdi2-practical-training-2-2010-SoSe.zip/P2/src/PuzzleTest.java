
/**
 * Test cases
 */

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.jgrapht.DirectedGraph;
import org.junit.Test;

public class PuzzleTest 
{
	@Test(expected=PuzzleFileFormatException.class)
	public void readTest1() throws IOException
	{
		new PuzzleInputOutput("test_1.txt");
	}
	@Test(expected=PuzzleFileFormatException.class)
	public void readTest2() throws IOException
	{
		new PuzzleInputOutput("test_2.txt");
	}
	@Test(expected=PuzzleFileFormatException.class)
	public void readTest3() throws IOException
	{
		new PuzzleInputOutput("test_3.txt");
	}
	@Test(expected=PuzzleFileFormatException.class)
	public void readTest4() throws IOException
	{
		new PuzzleInputOutput("test_4.txt");
	}
	@Test(expected=PuzzleFileFormatException.class)
	public void readTest5() throws IOException
	{
		new PuzzleInputOutput("test_5.txt");
	}
	@Test
	public void testEquals() throws IOException
	{
		PuzzleInputOutput pio = new PuzzleInputOutput("test_0.txt");
		PuzzleMove start = new PuzzleMove();
		PuzzleMove end   = new PuzzleMove();
		start.setState(pio.getPuzzleStart());
		end.setState(pio.getPuzzleDestination());
		Puzzle p = new Puzzle(start, end);
		p.init();
		p.findDestination();
		assertEquals(p.getCurrentState(), end);	// current state should be the destination
		assertFalse("Equals is not properly implemented.", start.equals(end));
		end = start;
		assertTrue("Equals is not properly implemented", start.equals(end));
	}
	@Test
	public void testEqualityCheck() throws IOException
	{
		PuzzleInputOutput pio = new PuzzleInputOutput("test_01.txt");
		PuzzleMove start = new PuzzleMove();
		PuzzleMove end   = new PuzzleMove();
		start.setState(pio.getPuzzleStart());
		end.setState(pio.getPuzzleDestination());
		Puzzle p = new Puzzle(start, end);
		p.init();
		p.findDestination();
		DirectedGraph<PuzzleMove, Integer> g = p.getGraph();
		// If start and destination are the same...
		assertFalse(p.numberOfProcessedStates() > 1);	//...no need to process more than one state
		assertFalse(g.vertexSet().size() > 1);			//...the graph should have only one node
	}
}
